public interface Visitor<Data> {
	public void visit(Data toBeVisied);
}
