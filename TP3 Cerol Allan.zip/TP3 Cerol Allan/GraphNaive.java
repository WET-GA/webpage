import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.Queue;
import java.util.ArrayDeque;

public class GraphNaive<Vertex, Edge> implements Graph<Vertex, Edge> {
	private Set<Vertex> vertices = new HashSet<Vertex>();
	private Set<Edge> edges = new HashSet<Edge>();
	private Map<Edge, Vertex[]> edgesToVertices = new HashMap<Edge, Vertex[]>();

	public GraphNaive() {
	}

	public void addVertex(Vertex v) {
		vertices.add(v);
	}

	public void addEdge(Edge e, Vertex[] vertices) {
		edges.add(e);
		edgesToVertices.put(e, vertices);
	}

	public void visitVerticesDepthFirst(Visitor<Vertex> visitor, Vertex v) {
		visitVerticesDepthFirst(visitor, v, new HashSet<Vertex>());
	}

	private void visitVerticesDepthFirst(Visitor<Vertex> visitor, Vertex v, Set<Vertex> visited) {
		if (visited.contains(v)) {
			return;
		}
		visitor.visit(v);
		visited.add(v);
		for (Vertex[] endPoints : edgesToVertices.values()) {
			for (int i = 0; i != endPoints.length; ++i) {
				if (endPoints[i].equals(v)) {
					visitVerticesDepthFirst(visitor, endPoints[1 - i], visited);
				}
			}
		}
	}

	public void visitVerticesBreadthFirst(Visitor<Vertex> visitor, Vertex v) {
		Queue<Vertex> toVisit = new ArrayDeque<Vertex>();
		toVisit.add(v);
		visitVerticesBreadthFirst(visitor, toVisit, new HashSet<Vertex>());
	}

	private void visitVerticesBreadthFirst(Visitor<Vertex> visitor, Queue<Vertex> toVisit, Set<Vertex> visited) {
		if (toVisit.isEmpty()) {
			return;
		}
		Vertex current = toVisit.remove();
		if (!visited.contains(current)) {
			visitor.visit(current);
			visited.add(current);
			for (Vertex[] endPoints : edgesToVertices.values()) {
				for (int i = 0; i != endPoints.length; ++i) {
					if (endPoints[i].equals(current)) {
						toVisit.add(endPoints[1 - i]);
					}
				}
			}
		}
		visitVerticesBreadthFirst(visitor, toVisit, visited);
	}

	public String toString() {
		String res = "" + vertices.size() + " vertices : \n";
		for (Vertex v : vertices) {
			res += v + ", ";
		}
		res += "\n" + edges.size() + " edges:\n";
		for (Map.Entry<Edge, Vertex[]> kv : edgesToVertices.entrySet()) {
			res += kv.getKey() + " :" + kv.getValue()[0] + " -- " + kv.getValue()[1] + "\n";
		}
		return res;
	}

	public void visitConnectedComponents(Visitor<Vertex> v) {
		// TODO !
	}

	public long maxDegree() {
		long max = -1L;
		HashMap<Vertex, Long> counts = new HashMap<>();
		for (Vertex[] verts : edgesToVertices.values()) {
			for (Vertex v : verts) {
				if (counts.containsKey(v)) {
					counts.put(v, counts.get(v) + 1);
				} else {
					counts.put(v, 1L);
					max = counts.get(v) > max ? counts.get(v) : max;
				}
			}
			return max;
		}

		return -1;

	}

	public double avgDegree() {
		return -1.;// TODO
	}

	public long nbOfLoops() {
		return -1;// TODO
	}

	public boolean areConnected(Vertex v0, Vertex v1) {
		return false;// TODO
	}

	public boolean visitPath(Visitor<Edge> ve, Visitor<Vertex> vv, Vertex v0, Vertex v1) {
		return areConnected(v0, v1); // TODO
	}

}
