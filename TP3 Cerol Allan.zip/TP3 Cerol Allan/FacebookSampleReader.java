
import java.util.Scanner;
import java.io.InputStream;

public class FacebookSampleReader {
	public static GraphNaive<Long, Long> readGraph(InputStream is) {
		GraphNaive<Long, Long> graph = new GraphNaive<Long, Long>();
		Scanner sc = new Scanner(System.in);
		for (long edgeId = 0; sc.hasNextLong(); ++edgeId) {
			Long v0 = new Long(sc.nextLong());
			graph.addVertex(v0);
			Long v1 = new Long(sc.nextLong());
			graph.addVertex(v1);
			graph.addEdge(new Long(edgeId), new Long[] { v0, v1 });
		}
		return graph;
	}

	public static void main(String[] args) {
		// System.out.print(readGraph(System.in));
		GraphNaive<Long, Long> graph = new GraphNaive<Long, Long>();
		graph.addVertex(1L);
		graph.addVertex(2L);
		// System.out.print(readGraph(graph));
	}
}
/////////////////////////////////////////
