
public interface Graph<Vertex, Edge> {
	public void addVertex(Vertex toAdd);

	public void addEdge(Edge toAdd, Vertex[] vertices);

	public void visitVerticesBreadthFirst(Visitor<Vertex> v, Vertex startVertex);

	public void visitVerticesDepthFirst(Visitor<Vertex> v, Vertex startVertex);

	public void visitConnectedComponents(Visitor<Vertex> v);

	public long maxDegree();

	public double avgDegree();

	public long nbOfLoops();

	public boolean areConnected(Vertex v0, Vertex v1);

	public boolean visitPath(Visitor<Edge> ve, Visitor<Vertex> vv, Vertex v0, Vertex v1);
}
//////////////////////////////////////////////
